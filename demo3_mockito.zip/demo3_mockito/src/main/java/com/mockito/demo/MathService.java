package com.mockito.demo;


public class MathService {

    public int add(int a, int b) {
        return a + b;
    }
}
