package mockitodemo2;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.mockito.demo.Calculator;
import com.mockito.demo.MathService;

@ExtendWith(MockitoExtension.class)
class CalculatorTest {

    @Mock
    MathService mathService;   // Dependency mocked
    @InjectMocks
    Calculator calculator;    // Class under test

    @Test
    void testAdd() {
        // Arrange - Stub
        when(mathService.add(10, 20)).thenReturn(30);
        // Assert
        assertEquals(30, calculator.add(10, 20));
        // Verify interaction
        verify(mathService).add(10, 20);
    }
}
