package com.capgemini.hibernate.demo8_hibernate_onetomany;

import jakarta.persistence.*;

@Entity
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String accountNumber;

	public Account() {
	}

	public Account(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	// Getters and Setters

	public Long getId() {
		return id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountNumber=" + accountNumber + "]";
	}
}
