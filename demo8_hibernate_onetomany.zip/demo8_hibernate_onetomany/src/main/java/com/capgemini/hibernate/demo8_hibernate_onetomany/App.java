package com.capgemini.hibernate.demo8_hibernate_onetomany;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.EntityTransaction;

import java.util.Arrays;

public class App {

    public static void main(String[] args) {

        // Step 1: Create EntityManagerFactory
        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("myPersistenceUnit");
        // Step 2: Create EntityManager
        EntityManager em = emf.createEntityManager();
        // Step 3: Begin Transaction
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        // Step 4: Create Accounts
        Account acc1 = new Account("ACC12345");
        Account acc2 = new Account("ACC67890");
        // Step 5: Create Customer and associate accounts
        Customer customer = new Customer(
                "John Doe",
                Arrays.asList(acc1, acc2)
        );
        // Step 6: Persist Customer
        // CascadeType.ALL will save Account objects automatically
        em.persist(customer);
        // Step 7: Commit transaction
        tx.commit();

        System.out.println("Customer and Accounts saved successfully!");

        // Step 8: Close resources
        em.close();
        emf.close();
    }
}
